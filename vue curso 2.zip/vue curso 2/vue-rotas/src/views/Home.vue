<template>
    <div>
        <h3 class="font-weight-light">Home</h3>
        <p>Cadastro de contatos com Vue + Vue Router</p>
    </div>
</template>
