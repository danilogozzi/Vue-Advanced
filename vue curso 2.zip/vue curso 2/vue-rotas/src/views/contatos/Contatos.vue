<template>
    <div>
        <router-view></router-view>
        <router-view name="contato-detalhes"></router-view>
    </div>
</template>

