<template>
  <div>
    <label>{{ customLabel }}</label>
    <input
      v-bind="$attrs"
      type="range"
      @input="atualizar"
      :class="inputClasses"
    />
  </div>
</template>

<script>
export default {
  //PERMITE QUE AS PROPRIEDADES PASSADAS QUE NÃO FOREM DECLARADAS, NÃO SEJA PASSADA PARA A DIV ROOT
  inheritAttrs: false,
  props: {
    label: String,
    value: [Number, String],
    inputClasses: [String, Object, Array],
  },
  data() {
    return {
      valorAtual: this.value || this.$attrs.min,
    };
  },
  methods: {
    atualizar(event) {
      const valor = event.target.value;
      this.$emit("input", valor);
      this.valorAtual = valor;
    },
  },
  computed: {
    customLabel() {
      return `${this.label} (R$ ${this.valorAtual})`;
    },
  },
};
</script>

<style>
</style>