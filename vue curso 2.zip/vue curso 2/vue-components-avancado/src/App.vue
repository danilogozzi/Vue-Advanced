<template>
  <div id="app" class="container">
    <h1>Components Dinâmicos</h1>
    <button @click="componentSelecionado = 'HomePage'">Home</button>
    <button @click="componentSelecionado = 'PostLista'">Posts</button>
    <button @click="componentSelecionado = 'SobrePage'">Sobre</button>
    <keep-alive :include="/HomePage | SobrePage/">
      <component :is="componentSelecionado" v-bind="propsAtuais"></component>
    </keep-alive>
  </div>
</template>
<script>
import HomePage from "./components/HomePage.vue";
import PostLista from "./components/PostLista.vue";
import SobrePage from "./components/SobrePage.vue";
export default {
  components: {
    HomePage,
    PostLista,
    SobrePage,
  },
  data() {
    return {
      componentSelecionado: "HomePage",
      posts: [
        {
          id: 1,
          titulo: "Components no Vue",
          conteudo: "Components são uma das peças mais importantes no Vue",
          autor: "Plínio Naves",
        },
        {
          id: 2,
          titulo: "Distribuindo conteúdo com Slots",
          conteudo: "Slots podem ser usados como repositórios de código HTML",
          autor: "Danilo Gozzi",
        },
      ],
    };
  },
  computed: {
    propsAtuais() {
      return this.componentSelecionado === "PostLista"
        ? { posts: this.posts }
        : {};
    },
  },
};
</script>
<style scoped>
.container {
  width: 960px;
  margin: auto;
}
</style>
