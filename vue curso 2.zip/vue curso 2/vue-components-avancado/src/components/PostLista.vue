<template>
  <div>
    <h2>Lista de posts</h2>
    <PostListaItemVue v-for="post in posts" :key="post.id" :post="post">
      <slot :meuPost="post"></slot>
    </PostListaItemVue>
  </div>
</template>

<script>
import PostListaItemVue from "./PostListaItem.vue";
export default {
  components: {
    PostListaItemVue,
  },
  props: {
    posts: {
      type: Array,
      required: true,
    },
  },
};
</script>

<style>
</style>