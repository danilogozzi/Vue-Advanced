<template>
    <h1>Curso de VueJS</h1>
</template>
