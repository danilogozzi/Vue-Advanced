module.exports = {
    outputDir: 'myDist'
}
