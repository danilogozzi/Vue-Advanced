import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

//TEMOS QUE CRIAR O $EVENTBUSS ANTES DA INSTÂNCIA ROOT - ESTAMOS CENTRALIZANDO DADOS E EVENTOS
export const eventBus = new Vue({
  methods: {
    //PODEMOS CENTRALIZAR METODOS COM EVENTBUS
    selecionarFilme(filmeSelecionado) {
      this.$emit('selecionarFilme', filmeSelecionado)
    },
    atualizarFilme(filmeAtualizado) {
      this.$emit('atualizarFilme', filmeAtualizado)
    }
  }
})

new Vue({
  render: h => h(App),
}).$mount('#app')
