<template>
  <li class="list-group-item">
    <span>{{ filme.titulo }} | {{ filme.ano }}</span>
    <button @click="selecionar" class="btn btn-success float-right">
      Selecionar
    </button>
  </li>
</template>
<script>
import { eventBus } from "../main";

export default {
  props: {
    /*titulo: {
      type: String, //REFININDO O TIPO DE PROPRIEDADE ESPERADA
      //required: true //OBRIGATORIO PASSAR UM VALOR PARA A PROPRIEDADE
      default() {
        return "Filmes";
      },
      validator(titulo) { VALIDANDO A PROPRIEDADE PASSADA
        return titulo.includes("Marvel");
      },
    },
    ano: {
      type: Number,
    },*/
    filme: {
      type: Object,
      required: true,
    },
  },
  methods: {
    selecionar(event) {
      //this.$emit("selecionarFilme", this.filme);
      //EVENTBUS AGORA QUEM EMITE O EVENTO
      //eventBus.$emit("selecionarFilme", this.filme);
      //METODO PASSADO PELO EVENTBUSS
      eventBus.selecionarFilme(this.filme);
    },
  },
  /*computed: {
    tituloConcatenado() {
      //PROPRIEDADES COMPUTADAS MONITORAM ALTERAÇÃO EM PROPRIEDADES
      return `Titulo: ${this.titulo}`;
    },
  },*/
};
</script>