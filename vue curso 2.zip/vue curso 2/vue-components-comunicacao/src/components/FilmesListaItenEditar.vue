<template>
  <div>
    <h2>Editar filme</h2>

    <div class="form-group">
      <label>Título:</label>
      <input
        type="text"
        class="form-control"
        placeholder="Insira o título"
        :value="filmeSelecionado.titulo"
        @input="
          filmeSelecionado = {
            propriedade: 'titulo',
            valor: $event.target.value,
          }
        "
      />
    </div>
    <div class="form-group">
      <label>Ano:</label>
      <input
        type="text"
        class="form-control"
        placeholder="Insira o ano"
        :value="filmeSelecionado.ano"
        @input="
          filmeSelecionado = {
            propriedade: 'ano',
            valor: $event.target.value,
          }
        "
      />
      <button @click="salvarFilme" class="btn btn-primary float-right">
        Salvar
      </button>
    </div>
  </div>
</template>
<script>
import { eventBus } from "../main";
export default {
  props: {
    filme: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      filmeLocal: this.filme,
    };
  },
  //FORMA CORREDA DE MANIPULAR PROPRIEDADES PASSADA DE PAI PRA FILHO UNIDIRECIONALMENTE
  computed: {
    filmeSelecionado: {
      //SETANDO NOVO VALOR
      set(dados) {
        this.filmeLocal = Object.assign({}, this.filmeLocal, {
          [dados.propriedade]: dados.valor,
        });
      },
      //PEGANDO VALOR DA PRORIEDADE
      get() {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        return this.filme;
      },
    },
  },
  watch: {
    filme(novoFilme) {
      // crie o watcher na prop "filme"
      this.filmeLocal = Object.assign({}, novoFilme);
    },
  },
  methods: {
    salvarFilme(event) {
      //this.$emit("atualizarFilme", this.filmeLocal);
      //EVENTO VIA EVENTBUS
      eventBus.atualizarFilme(this.filmeLocal);
    },
  },
};
</script>